using System.Reflection;

[assembly: AssemblyTitle("CreateZipFile")]
[assembly: AssemblyDescription("Free C# IDE")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
