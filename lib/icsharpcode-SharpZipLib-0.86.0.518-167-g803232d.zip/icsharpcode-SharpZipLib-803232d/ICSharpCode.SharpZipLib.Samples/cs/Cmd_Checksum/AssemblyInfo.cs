using System.Reflection;

[assembly: AssemblyTitle("Cmd_Crc")]
[assembly: AssemblyDescription("file checksum generator")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
