using System.Reflection;

[assembly: AssemblyTitle("Cmd_BZip2")]
[assembly: AssemblyDescription("bzip2 based file compression")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
